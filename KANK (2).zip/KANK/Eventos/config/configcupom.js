const { ApplicationCommandType, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ModalBuilder, TextInputBuilder, ChannelSelectMenuBuilder, ChannelType, RoleSelectMenuBuilder, StringSelectMenuBuilder } = require("discord.js");
const vendas = require("../../DataBase/vindex");
const ticket = require("../../DataBase/tindex");
const emoji = require("../../DataBase/emojis.json");
const owner = require("../../DataBase/owner.json");
const axios = require("axios");
const fs = require("fs");


module.exports = {
    name:"interactionCreate",
    run:async(interaction, client) => {
        const customId = interaction.customId;
        if(!customId) return;

        const userid = customId.split("_")[0];
        const id = customId.split("_")[1];
        
        if(!id) return;
        const cupom = await vendas.cupom.get(`${id}`);
        if(!cupom) return;
        if(interaction.user.id !== userid) return;
        

        if(customId.endsWith("_configdesconto")) {
            const modal = new ModalBuilder()
            .setCustomId(`${userid}_${id}_configdescontomodal`)
            .setTitle("💢 - Configurar Desconto/Porcentagem");

            const text = new TextInputBuilder()
            .setCustomId("text")
            .setStyle(1)
            .setLabel("Coloque o Desconto/porcentagem")
            .setPlaceholder("Lembre porcentagem e desconto é diferente!")
            .setRequired(true);

            modal.addComponents(new ActionRowBuilder().addComponents(text));

            return interaction.showModal(modal);
        }

        if(customId.endsWith("_configdescontomodal")) {
            const text = interaction.fields.getTextInputValue("text");
            if(isNaN(text)) return interaction.reply({content:`${emoji.aviso} | Digite um Valor Valido!`, ephemeral:true});
            if(cupom.type === "dinheiro") {
                const preco = parseFloat(text).toFixed(2);
                if(preco <= 0) return interaction.reply({content:`${emoji.aviso} | Coloque um Valor Acima de 0`, ephemeral:true});
                await vendas.cupom.set(`${id}.dinheiro`, preco);
                await  cup();

            } else {
                const preco = parseInt(text);
                if(preco < 1) return interaction.reply({content:`${emoji.aviso} | Coloque um Valor Acima de 1`, ephemeral:true});
                await vendas.cupom.set(`${id}.porcentagem`, preco);
                await cup();
            }
        }

        if(customId.endsWith("_valormincupom")) {
            const modal = new ModalBuilder()
            .setCustomId(`${userid}_${id}_valorminmodal`)
            .setTitle("💢 - Alterar Valor Minimo do Cupom");

            const text = new TextInputBuilder()
            .setCustomId("text")
            .setStyle(1)
            .setRequired(true)
            .setLabel("Coloque o Valor Minimo:")
            .setPlaceholder("10");

            modal.addComponents(new ActionRowBuilder().addComponents(text));

            return interaction.showModal(modal);
        }

        if(customId.endsWith("_valorminmodal")) {
            const text = parseInt(interaction.fields.getTextInputValue("text"));
            if(isNaN(text)) return interaction.reply({content:`${emoji.aviso} | Coloque Apenas numeros!`, ephemeral:true});
            await vendas.cupom.set(`${id}.valormin`, text);
            cup();
        }

        if(customId.endsWith("_quantidadecupom")) {
            const modal = new ModalBuilder()
            .setCustomId(`${userid}_${id}_quantidadecupommodal`)
            .setTitle("💢 - Alterar Quantidade do Cupom");

            const text = new TextInputBuilder()
            .setCustomId("text")
            .setStyle(1)
            .setRequired(true)
            .setLabel("Coloque a Quantidade: ")
            .setPlaceholder("10");

            modal.addComponents(new ActionRowBuilder().addComponents(text));

            return interaction.showModal(modal);
        }

        if(customId.endsWith("_quantidadecupommodal")) {
            const text = parseInt(interaction.fields.getTextInputValue("text"));
            if(isNaN(text)) return interaction.reply({content:`${emoji.aviso} | Coloque Apenas numeros!`, ephemeral:true});
            if(text <= 0) return interaction.reply({content:`${emoji.aviso} | Nâo é possivel adicionar abaixo de 1`, ephemeral:true})
            await vendas.cupom.add(`${id}.quantidade`, text);
            cup();
        }

        if(customId.endsWith("_removerquantidadecupom")) {
            const modal = new ModalBuilder()
            .setCustomId(`${userid}_${id}_removerquantidadecupommodal`)
            .setTitle("💢 - Alterar Quantidade do Cupom");

            const text = new TextInputBuilder()
            .setCustomId("text")
            .setStyle(1)
            .setRequired(true)
            .setLabel("Coloque a Quantidade que vai ser removido: ")
            .setPlaceholder("10");

            modal.addComponents(new ActionRowBuilder().addComponents(text));

            return interaction.showModal(modal);
        }

        if(customId.endsWith("_removerquantidadecupommodal")) {
            const text = parseInt(interaction.fields.getTextInputValue("text"));
            if(isNaN(text)) return interaction.reply({content:`${emoji.aviso} | Coloque Apenas numeros!`, ephemeral:true});
            if(text > cupom.quantidade) return interaction.reply({content:`${emoji.aviso} | Nâo é possivel remover acima de ${cupom.quantidade}`, ephemeral:true})
            if(text <= 0) return interaction.reply({content:`${emoji.aviso} | Nâo é possivel remover abaixo de 1`, ephemeral:true});
            await vendas.cupom.substr(`${id}.quantidade`, text);
            cup();
        }

        if(customId.endsWith("_deletecupom")) {
            const modal = new ModalBuilder()
            .setCustomId(`${userid}_${id}_deletecupommodal`)
            .setTitle("💢 - Deletar Cupom");

            const text = new TextInputBuilder()
            .setCustomId("text")
            .setStyle(1)
            .setPlaceholder("SIM")
            .setLabel("COLOQUE SIM PARA DELETAR")
            .setMaxLength(3)
            .setMinLength(3);

            modal.addComponents(new ActionRowBuilder().addComponents(text));

            return interaction.showModal(modal);
        }

        if(customId.endsWith("_deletecupommodal")) {
            const text = interaction.fields.getTextInputValue("text");
            if(text !== "SIM") return interaction.reply({content:`${emoji.sim} | Cancelado com sucesso!`, ephemeral:true});
            await vendas.cupom.delete(`${id}`);
            interaction.update({embeds:[], components:[], content:`${emoji.sim} | Cupom Deletado com sucesso!`, ephemeral:true});
        }

        async function cup() {
            const cupom = await vendas.cupom.get(`${id}`);
            await interaction.update({
            embeds:[
                new EmbedBuilder()
                .setTitle(`${interaction.guild.name} | Gerenciar Cupom`)
                .setThumbnail(interaction.client.user.displayAvatarURL())
                .setFooter({text:`${interaction.guild.name} - Todos os Direitos Reservados`,iconURL: interaction.guild.iconURL()})
                .setDescription(`Cupom sendo gerenciado: \n\n **${emoji.lupa} | Nome:** \`${id}\` \n **${emoji.dinheiro} | ${cupom.type === "dinheiro" ? `Desconto do Preço: \`R$${cupom.dinheiro}\``: `Porcentagem de Desconto: \`${cupom.porcentagem}%\``}** \n ${emoji.carrinho}** | Valor Mínimo:** \`R$${cupom.valormin}\` \n ${emoji.bagmoney}** | Quantidade:** ${cupom.quantidade}`)
            ],
            components:[
                new ActionRowBuilder()
                .addComponents(
                    new ButtonBuilder()
                    .setCustomId(`${userid}_${id}_configdesconto`)
                    .setLabel("Configurar Desconto/Porcentagem")
                    .setStyle(3)
                    .setEmoji(emoji.dinheiro),
                    new ButtonBuilder()
                    .setCustomId(`${userid}_${id}_valormincupom`)
                    .setLabel("Valor Mínimo")
                    .setStyle(3)
                    .setEmoji(emoji.carrinho),
                ),
                new ActionRowBuilder()
                .addComponents(
                    new ButtonBuilder()
                    .setCustomId(`${userid}_${id}_quantidadecupom`)
                    .setLabel("Adicionar Quantidade")
                    .setStyle(3)
                    .setEmoji(emoji.adicionar),
                    new ButtonBuilder()
                    .setCustomId(`${userid}_${id}_removerquantidadecupom`)
                    .setLabel("Remover Quantidade")
                    .setStyle(4)
                    .setEmoji(emoji.remover),
                    ),
                    new ActionRowBuilder()
                    .addComponents(
                        new ButtonBuilder()
                        .setCustomId(`${userid}_${id}_deletecupom`)
                        .setLabel("Deletar Cupom")
                        .setStyle(2)
                        .setEmoji(emoji.lixeira),
                        )
            ]
        })
    }
    }}