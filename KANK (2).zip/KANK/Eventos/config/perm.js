const { ApplicationCommandType, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ModalBuilder, TextInputBuilder, ChannelSelectMenuBuilder, ChannelType, RoleSelectMenuBuilder } = require("discord.js");
const vendas = require("../../DataBase/vindex");
const ticket = require("../../DataBase/tindex");
const emoji = require("../../DataBase/emojis.json");
const next = require("../../DataBase/index");
const owner = require("../../DataBase/owner.json");
const {botconfig, configvendas, configvendasedit, configpayments, configmercadopago, configmercadopagoedit, configchannels, configticket, configgeraisticket, configembedfora, configembed, configembedforaedit, buttonembedfora, buttonembedforaedit, configembeddentro, configembeddentroedit} = require("../../Functions/functionConfig/botconfig")
const axios = require("axios");



module.exports = {
    name:"interactionCreate",
    run:async(interaction, client) => {

        if(interaction.isButton()) {
            const customId = interaction.customId;

            if(customId === "addpermbot") {
                const modal = new ModalBuilder()
                .setCustomId(`addpermbot_modal`)
                .setTitle("➕ - Adicionar Permissão");

                const text = new TextInputBuilder()
                .setCustomId("text")
                .setStyle(1)
                .setRequired(true)
                .setLabel("Qual é o ID do Usuario?")
                .setPlaceholder("Digite Aqui");

                modal.addComponents(new ActionRowBuilder().addComponents(text));

                return interaction.showModal(modal);
            }

            if(customId === "clearpermbot") {
                const modal = new ModalBuilder()
                .setCustomId(`clearpermbot_modal`)
                .setTitle("🔄 - Limpar Permissão");

                const text = new TextInputBuilder()
                .setCustomId("text")
                .setStyle(1)
                .setRequired(true)
                .setLabel("Digite SIM:")
                .setMaxLength(3)
                .setMinLength(3)
                .setPlaceholder("SIM");

                modal.addComponents(new ActionRowBuilder().addComponents(text));

                return interaction.showModal(modal);
            }

            if(customId === "removerpermbot") {
                const modal = new ModalBuilder()
                .setCustomId(`removerpermbot_modal`)
                .setTitle("➖ - Remover Permissão");

                const text = new TextInputBuilder()
                .setCustomId("text")
                .setStyle(1)
                .setRequired(true)
                .setLabel("Qual é o ID do Usuario?")
                .setPlaceholder("Digite Aqui");

                modal.addComponents(new ActionRowBuilder().addComponents(text));

                return interaction.showModal(modal);
            }
        }

        if(interaction.isModalSubmit()) {
            const customId = interaction.customId;
            if(customId === "addpermbot_modal") {
                const text = interaction.fields.getTextInputValue("text");
                const user = interaction.guild.members.cache.get(text);
                if(!user) return interaction.reply({content:`${emoji.aviso} | Coloque ID de um Usuario Valido!`, ephemeral:true});
                if(await next.perm.get(`${text}`)) return interaction.reply({content:`${emoji.aviso} | Este Usuario já tem permissão!`, ephemeral:true});
                await next.perm.set(`${user.id}`, user.id);
                const all = await next.perm.all();
        let msg = "";
        if(all.length <= 0) {
            msg = "**Adicione Permissão para Alguem que ela Irá aparecer aqui!**";
        } else {
            all.map((rs, index) => {
                msg += `${index + 1}° | <@${rs.ID}> - \`${rs.ID}\` \n`
            });
        }

        interaction.update({
            embeds:[
                new EmbedBuilder()
                .setTitle(`${interaction.guild.name} | Configurar Permissões`)
                .setDescription(`Olá ***${interaction.user.username}*** Aqui está a lista de quem tem permissão: \n\n ${msg}`)
            ],
            components:[
                new ActionRowBuilder()
                .addComponents(
                    new ButtonBuilder()
                    .setCustomId("addpermbot")
                    .setLabel("Adicionar Permissão")
                    .setStyle(3)
                    .setEmoji(emoji.adicionar),
                    new ButtonBuilder()
                    .setCustomId("clearpermbot")
                    .setLabel("Limpar Permissão")
                    .setStyle(2)
                    .setEmoji(emoji.lixeira),
                    new ButtonBuilder()
                    .setCustomId("removerpermbot")
                    .setLabel("Remover Permissão")
                    .setStyle(4)
                    .setEmoji(emoji.remover),
                )
            ],
            ephemeral:true
        })

            }
            if(customId === "clearpermbot_modal") {
                const text = interaction.fields.getTextInputValue("text");
                if(text !== "SIM") return interaction.reply({content:`${emoji.sim} | Cancelado com sucesso..`, ephemeral:true});

                await next.perm.deleteAll();
                const all = await next.perm.all();
        let msg = "";
        if(all.length <= 0) {
            msg = "**Adicione Permissão para Alguem que ela Irá aparecer aqui!**";
        } else {
            all.map((rs, index) => {
                msg += `${index + 1}° | <@${rs.ID}> - \`${rs.ID}\` \n`
            });
        }

        interaction.update({
            embeds:[
                new EmbedBuilder()
                .setTitle(`${interaction.guild.name} | Configurar Permissões`)
                .setDescription(`Olá ***${interaction.user.username}*** Aqui está a lista de quem tem permissão: \n\n ${msg}`)
            ],
            components:[
                new ActionRowBuilder()
                .addComponents(
                    new ButtonBuilder()
                    .setCustomId("addpermbot")
                    .setLabel("Adicionar Permissão")
                    .setStyle(3)
                    .setEmoji(emoji.adicionar),
                    new ButtonBuilder()
                    .setCustomId("clearpermbot")
                    .setLabel("Limpar Permissão")
                    .setStyle(2)
                    .setEmoji(emoji.lixeira),
                    new ButtonBuilder()
                    .setCustomId("removerpermbot")
                    .setLabel("Remover Permissão")
                    .setStyle(4)
                    .setEmoji(emoji.remover),
                )
            ],
            ephemeral:true
        })

            }

            if(customId === "removerpermbot_modal") {
                const text = interaction.fields.getTextInputValue("text");
                const user = interaction.guild.members.cache.get(text);
                if(!user) return interaction.reply({content:`${emoji.aviso} | Coloque ID de um Usuario Valido!`, ephemeral:true});
                if(!await next.perm.get(`${text}`)) return interaction.reply({content:`${emoji.aviso} | Este Usuario não tem permissão!`, ephemeral:true});
                await next.perm.delete(`${user.id}`);
                const all = await next.perm.all();
        let msg = "";
        if(all.length <= 0) {
            msg = "**Adicione Permissão para Alguem que ela Irá aparecer aqui!**";
        } else {
            all.map((rs, index) => {
                msg += `${index + 1}° | <@${rs.ID}> - \`${rs.ID}\` \n`
            });
        }

        interaction.update({
            embeds:[
                new EmbedBuilder()
                .setTitle(`${interaction.guild.name} | Configurar Permissões`)
                .setDescription(`Olá ***${interaction.user.username}*** Aqui está a lista de quem tem permissão: \n\n ${msg}`)
            ],
            components:[
                new ActionRowBuilder()
                .addComponents(
                    new ButtonBuilder()
                    .setCustomId("addpermbot")
                    .setLabel("Adicionar Permissão")
                    .setStyle(3)
                    .setEmoji(emoji.adicionar),
                    new ButtonBuilder()
                    .setCustomId("clearpermbot")
                    .setLabel("Limpar Permissão")
                    .setStyle(2)
                    .setEmoji(emoji.lixeira),
                    new ButtonBuilder()
                    .setCustomId("removerpermbot")
                    .setLabel("Remover Permissão")
                    .setStyle(4)
                    .setEmoji(emoji.remover),
                )
            ],
            ephemeral:true
        })

            }
        }
    }}