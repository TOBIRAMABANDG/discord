const { ApplicationCommandType, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ModalBuilder, TextInputBuilder, ChannelSelectMenuBuilder, ChannelType, RoleSelectMenuBuilder } = require("discord.js");
const vendas = require("../../DataBase/vindex");
const ticket = require("../../DataBase/tindex");
const emoji = require("../../DataBase/emojis.json");
const owner = require("../../DataBase/owner.json");
const {botconfig, configvendas, configvendasedit, configpayments, configmercadopago, configmercadopagoedit, configchannels, configticket, configgeraisticket, configembedfora, configembed, configembedforaedit, buttonembedfora, buttonembedforaedit, configembeddentro, configembeddentroedit} = require("../../Functions/functionConfig/botconfig")
const axios = require("axios");



module.exports = {
    name:"interactionCreate",
    run:async(interaction, client) => {
        const customId = interaction.customId;
        if(!customId) return;
        const userid = customId.split("_")[0];
        if(interaction.user.id !== userid) return;

        if(customId.endsWith("_configvendas")) {
            try {
                await configvendas(interaction, client);
            } catch (err){
                interaction.message.edit({content:`${emoji.nao} | Ocorreu um erro, use o comando novamente! \n\n Mensagem do Erro: ${err.message}`, embeds:[],components:[],files:[]});
            }
        }

        if(customId.endsWith("_voltarconfigvendas")) {
            try {
                await botconfig(interaction, client);
            } catch (err){
                interaction.message.edit({content:`${emoji.nao} | Ocorreu um erro, use o comando novamente! \n\n Mensagem do Erro: ${err.message}`, embeds:[],components:[],files:[]});
            }
        }

        if(customId.endsWith("_configterms")) {
            const modal = new ModalBuilder()
            .setCustomId(`${userid}_configterms_modal`)
            .setTitle("✏ | Configurar Termos");

            const text = new TextInputBuilder()
            .setCustomId("text")
            .setLabel("Coloque o termo que você deseja")
            .setValue(`${await vendas.vconfig.get("terms")}`)
            .setRequired(true)
            .setMinLength(2)
            .setPlaceholder("Isso é para o carrinho!")
            .setStyle(2);

            modal.addComponents(new ActionRowBuilder().addComponents(text));

            return interaction.showModal(modal);
        }

        if(customId.endsWith("_configterms_modal")){
            const text = interaction.fields.getTextInputValue("text");
            await interaction.reply({content:`${emoji.loading} | Aguarde um momento...`, ephemeral:true});

            try {
                await vendas.vconfig.set(`terms`, text);
                await interaction.editReply({
                    content:`${interaction.user}`,
                    embeds:[
                        new EmbedBuilder()
                        .setDescription(`> - **Termos de Compra Atualizada com Sucesso!** \n\n ${text}`)
                    ]
                })
            } catch (err){
                interaction.editReply({content:`Ocorreu um erro... Use o comando novamente! \n\n Mensagem do Erro: ${err.message}`});
            }

        }

        if(customId.endsWith("_sistemadevendasonoff")) {
            const simnao = await vendas.vconfig.get("vendasonoff");
            if(simnao === true) {
                await vendas.vconfig.set("vendasonoff", false);
            } else {
                await vendas.vconfig.set("vendasonoff", true);
            }
            configvendas(interaction, client);
        }

        if(customId.endsWith("_configpayments")) {
            await configpayments(interaction, client);
        }
        
        if(customId.endsWith("_mercadopago")) {
            await configmercadopago(interaction, client);
        }

        if(customId.endsWith("_pixonoff")) {
            const simnao = await vendas.vconfig.get("pix");
            if(simnao === true) {
                await vendas.vconfig.set("pix", false);
            } else {
                await vendas.vconfig.set("pix", true);
            }
            configmercadopago(interaction, client);
        }

        if(customId.endsWith("_qrcode")) {
            const simnao = await vendas.vconfig.get("qrcode");
            if(simnao === true) {
                await vendas.vconfig.set("qrcode", false);
            } else {
                await vendas.vconfig.set("qrcode", true);
            }
            configmercadopago(interaction, client);
        }

        if(customId.endsWith("_siteonoff")) {
            const simnao = await vendas.vconfig.get("siteonoff");
            if(simnao === true) {
                await vendas.vconfig.set("siteonoff", false);
            } else {
                await vendas.vconfig.set("siteonoff", true);
            }
            configmercadopago(interaction, client);
        }

        if(customId.endsWith("_tempopagar")) {
            const modal = new ModalBuilder()
            .setCustomId(`${userid}_tempopagarmodal`)
            .setTitle("💢 - Tempo para Pagar");

            const text = new TextInputBuilder()
            .setCustomId("text")
            .setLabel("Coloque o tempo em minutos:")
            .setStyle(1)
            .setPlaceholder("5 a 25 minutos")
            .setRequired(true)
            .setMaxLength(2)
            .setMinLength(1);

            modal.addComponents(new ActionRowBuilder().addComponents(text));

            return interaction.showModal(modal);
        }

        if(customId.endsWith("_tempopagarmodal")) {
            const text = parseInt(interaction.fields.getTextInputValue("text"));

            if(isNaN(text)) return interaction.reply({content:`${emoji.aviso} | Coloque um valor Valido!`, ephemeral:true});
            if(text < 5 ) return interaction.reply({content:`${emoji.aviso} | Coloque no minimo 5 Minutos!`, ephemeral:true});
            if(text > 25 ) return interaction.reply({content:`${emoji.aviso} | Coloque no maximo 25 Minutos!`, ephemeral:true});

            await vendas.vconfig.set(`tempopagar`, Number(text));
            await configmercadopago(interaction, client);
        }

        if(customId.endsWith("_acesstoken")) {
            const modal = new ModalBuilder()
            .setCustomId(`${userid}_acesstokenmodal`)
            .setTitle("💢 - Acess Token Mercado Pago");

            const text = new TextInputBuilder()
            .setCustomId("text")
            .setLabel("Digite o Acess-Token:")
            .setStyle(1)
            .setPlaceholder("APP_USR....")
            .setRequired(true);

            modal.addComponents(new ActionRowBuilder().addComponents(text));

            return interaction.showModal(modal);
        }

        if(customId.endsWith("_acesstokenmodal")) {
            const text = interaction.fields.getTextInputValue("text");
            await interaction.reply({
                content:`🔁 | Verificando...`,
                ephemeral:true
            });
            const url = `https://api.mercadopago.com/users/me`;

try {
    const response = await axios.get(url, {
        headers: {
          'Authorization': `Bearer ${text}`
        }
      })
      ;
    if (response.status === 200) {
        await vendas.vconfig.set(`mp`, text);
        
        configmercadopagoedit(interaction, client)
        await interaction.editReply({
            content:`✅ | Access Token Alterado com sucesso!`
        })
    }
} catch (error) {
    if (error.response && error.response.status === 400) {
        await interaction.editReply({
            content:`⚠️ | Access Token inválido!\nMercadoPagoError: Must provide your access_token to proceed\n\n> Tutorial para pegar o Access Token: [CliqueAqui](https://youtu.be/w7kyGZUrkVY)\n> Lembre-se de cadastrar uma chave pix na sua conta mercado pago!`
        })
    } else {
        await interaction.editReply({
            content:`⚠️ | Ocorreu um um erro ao tentar consultar o seu Acess_Token\nMensagem do Erro: ${error.message}`
        })
    }}

        }

        if(customId.endsWith("_configchannel")) {
            try {
                await configchannels(interaction, client);
            } catch (err){
                interaction.message.edit({content:`${emoji.nao} | Ocorreu um erro, use o comando novamente! \n\n Mensagem do Erro: ${err.message}`, embeds:[],components:[],files:[]});
            }
        }

        if(customId.endsWith("_configchannelpublic")) {
            const channel = interaction.guild.channels.cache.get(await vendas.vconfig.get("public")) || "`Nâo Configurado`"
            await interaction.update({
                embeds:[
                    new EmbedBuilder()
                    .setTitle(`${interaction.guild.name} | Configurar Canais`)
                    .setDescription(`${emoji.setadireita} Selecione o canal que será enviado as logs publicas, Canal Setado Atualmente: (${channel})`)
                ],
                components:[
                    new ActionRowBuilder()
                    .addComponents(
                        new ChannelSelectMenuBuilder()
                        .setChannelTypes(ChannelType.GuildText)
                        .setCustomId(`${userid}_selectpublic`)
                        .setPlaceholder("Escolha um canal para ser setado")
                        .setMaxValues(1)
                    ),
                    new ActionRowBuilder()
                    .addComponents(
                        new ButtonBuilder()
                        .setCustomId(`${userid}_deletepublic`)
                        .setLabel("Remover Canal")
                        .setStyle(4)
                        .setEmoji(emoji.lixeira)
                    ),
                    new ActionRowBuilder()
                    .addComponents(
                        new ButtonBuilder()
                        .setCustomId(`${userid}_configchannel`)
                        .setLabel("Voltar")
                        .setStyle(2)
                        .setEmoji(emoji.voltar)
                    )
                ]
            })
        }
        if(customId.endsWith("_selectpublic")) {
            const id = interaction.values[0];
            try {
                await vendas.vconfig.set("public", id);
                await configchannels(interaction, client);
            } catch (err){
                interaction.message.edit({content:`${emoji.nao} | Ocorreu um erro, use o comando novamente! \n\n Mensagem do Erro: ${err.message}`, embeds:[],components:[],files:[]});
            }
        }

        if(customId.endsWith("_deletepublic")) {
            try {
                await vendas.vconfig.set("public", "Não Configurado");
                await configchannels(interaction, client);
            } catch (err){
                interaction.message.edit({content:`${emoji.nao} | Ocorreu um erro, use o comando novamente! \n\n Mensagem do Erro: ${err.message}`, embeds:[],components:[],files:[]});
            }
        }

        if(customId.endsWith("_configchannelstaff")) {
            const channel = interaction.guild.channels.cache.get(await vendas.vconfig.get("logs")) || "`Nâo Configurado`"
            await interaction.update({
                embeds:[
                    new EmbedBuilder()
                    .setTitle(`${interaction.guild.name} | Configurar Canais`)
                    .setDescription(`${emoji.setadireita} Selecione o canal que será enviado as logs staff's, Canal Setado Atualmente: (${channel})`)
                ],
                components:[
                    new ActionRowBuilder()
                    .addComponents(
                        new ChannelSelectMenuBuilder()
                        .setChannelTypes(ChannelType.GuildText)
                        .setCustomId(`${userid}_selectstaff`)
                        .setPlaceholder("Escolha um canal para ser setado")
                        .setMaxValues(1)
                    ),
                    new ActionRowBuilder()
                    .addComponents(
                        new ButtonBuilder()
                        .setCustomId(`${userid}_deletestaff`)
                        .setLabel("Remover Canal")
                        .setStyle(4)
                        .setEmoji(emoji.lixeira)
                    ),
                    new ActionRowBuilder()
                    .addComponents(
                        new ButtonBuilder()
                        .setCustomId(`${userid}_configchannel`)
                        .setLabel("Voltar")
                        .setStyle(2)
                        .setEmoji(emoji.voltar)
                    )
                ]
            })
        }
        if(customId.endsWith("_selectstaff")) {
            const id = interaction.values[0];
            try {
                await vendas.vconfig.set("logs", id);
                await configchannels(interaction, client);
            } catch (err){
                interaction.message.edit({content:`${emoji.nao} | Ocorreu um erro, use o comando novamente! \n\n Mensagem do Erro: ${err.message}`, embeds:[],components:[],files:[]});
            }
        }

        if(customId.endsWith("_deletestaff")) {
            try {
                await vendas.vconfig.set("logs", "Não Configurado");
                await configchannels(interaction, client);
            } catch (err){
                interaction.message.edit({content:`${emoji.nao} | Ocorreu um erro, use o comando novamente! \n\n Mensagem do Erro: ${err.message}`, embeds:[],components:[],files:[]});
            }
        }

        if(customId.endsWith("_configcategory")) {
            const channel = interaction.guild.channels.cache.get(await vendas.vconfig.get("category")) || "`Nâo Configurado`"
            await interaction.update({
                embeds:[
                    new EmbedBuilder()
                    .setTitle(`${interaction.guild.name} | Configurar Categoria`)
                    .setDescription(`${emoji.setadireita} Selecione a categoria de carrinho, Categoria Setado Atualmente: (${channel})`)
                ],
                components:[
                    new ActionRowBuilder()
                    .addComponents(
                        new ChannelSelectMenuBuilder()
                        .setChannelTypes(ChannelType.GuildCategory)
                        .setCustomId(`${userid}_selectcategory`)
                        .setPlaceholder("Escolha uma categoria para ser setado")
                        .setMaxValues(1)
                    ),
                    new ActionRowBuilder()
                    .addComponents(
                        new ButtonBuilder()
                        .setCustomId(`${userid}_deletecategory`)
                        .setLabel("Remover Categoria")
                        .setStyle(4)
                        .setEmoji(emoji.lixeira)
                    ),
                    new ActionRowBuilder()
                    .addComponents(
                        new ButtonBuilder()
                        .setCustomId(`${userid}_configchannel`)
                        .setLabel("Voltar")
                        .setStyle(2)
                        .setEmoji(emoji.voltar)
                    )
                ]
            })
        }
        if(customId.endsWith("_selectcategory")) {
            const id = interaction.values[0];
            try {
                await vendas.vconfig.set("category", id);
                await configchannels(interaction, client);
            } catch (err){
                interaction.message.edit({content:`${emoji.nao} | Ocorreu um erro, use o comando novamente! \n\n Mensagem do Erro: ${err.message}`, embeds:[],components:[],files:[]});
            }
        }

        if(customId.endsWith("_deletecategory")) {
            try {
                await vendas.vconfig.set("category", "Não Configurado");
                await configchannels(interaction, client);
            } catch (err){
                interaction.message.edit({content:`${emoji.nao} | Ocorreu um erro, use o comando novamente! \n\n Mensagem do Erro: ${err.message}`, embeds:[],components:[],files:[]});
            }
        }
        
        if(customId.endsWith("_configrolecliente")) {
            const channel = interaction.guild.roles.cache.get(await vendas.vconfig.get("role")) || "`Nâo Configurado`"
            await interaction.update({
                embeds:[
                    new EmbedBuilder()
                    .setTitle(`${interaction.guild.name} | Configurar Cargo`)
                    .setDescription(`${emoji.setadireita} Selecione o cargo que será colocado nos clientes, cargo Setado Atualmente: (${channel})`)
                ],
                components:[
                    new ActionRowBuilder()
                    .addComponents(
                        new RoleSelectMenuBuilder()
                        .setCustomId(`${userid}_selectrole`)
                        .setMaxValues(1)
                        .setPlaceholder("Selecione o Cargo de Cliente")
                    ),
                    new ActionRowBuilder()
                    .addComponents(
                        new ButtonBuilder()
                        .setCustomId(`${userid}_deleterole`)
                        .setLabel("Remover Cargo")
                        .setStyle(4)
                        .setEmoji(emoji.lixeira)
                    ),
                    new ActionRowBuilder()
                    .addComponents(
                        new ButtonBuilder()
                        .setCustomId(`${userid}_configchannel`)
                        .setLabel("Voltar")
                        .setStyle(2)
                        .setEmoji(emoji.voltar)
                    )
                ]
            })
        }
        if(customId.endsWith("_selectrole")) {
            const id = interaction.values[0];
            try {
                await vendas.vconfig.set("role", id);
                await configchannels(interaction, client);
            } catch (err){
                interaction.message.edit({content:`${emoji.nao} | Ocorreu um erro, use o comando novamente! \n\n Mensagem do Erro: ${err.message}`, embeds:[],components:[],files:[]});
            }
        }

        if(customId.endsWith("_deleterole")) {
            try {
                await vendas.vconfig.set("role", "Não Configurado");
                await configchannels(interaction, client);
            } catch (err){
                interaction.message.edit({content:`${emoji.nao} | Ocorreu um erro, use o comando novamente! \n\n Mensagem do Erro: ${err.message}`, embeds:[],components:[],files:[]});
            }
        }

        if(customId.endsWith("_configticket")) {
            try {
                await configticket(interaction, client);
            } catch (err){
                interaction.message.edit({content:`${emoji.nao} | Ocorreu um erro, use o comando novamente! \n\n Mensagem do Erro: ${err.message}`, embeds:[],components:[],files:[]});
            }            
        }

        if(customId.endsWith("_ativarticket")) {
            try {
                const simnao = await ticket.tconfig.get("ticketonoff");
            if(simnao === true) {
                await ticket.tconfig.set("ticketonoff", false);
            } else {
                await ticket.tconfig.set("ticketonoff", true);
            }
            configticket(interaction, client);
            } catch (err){
                interaction.message.edit({content:`${emoji.nao} | Ocorreu um erro, use o comando novamente! \n\n Mensagem do Erro: ${err.message}`, embeds:[],components:[],files:[]});
            }     
        }

        if(customId.endsWith("_configgeraisticket")) {
            try {
                configgeraisticket(interaction, client);
            } catch (err){
                interaction.message.edit({content:`${emoji.nao} | Ocorreu um erro, use o comando novamente! \n\n Mensagem do Erro: ${err.message}`, embeds:[],components:[],files:[]});
            }     
        }

        if(customId.endsWith("_logsticket")) {
            const channel = interaction.guild.channels.cache.get(await ticket.tconfig.get("logs")) || "`Não Configurado`";

            await interaction.update({
                embeds:[
                    new EmbedBuilder()
                    .setThumbnail(interaction.client.user.displayAvatarURL())
                    .setFooter({text:`${interaction.client.user.username} - Todos os Direitos Reservados`, iconURL: interaction.client.user.displayAvatarURL()})
                    .setTitle(`${interaction.guild.name} | Selecionar Canal de Logs`)
                    .setDescription(`${emoji.setadireita} Escolha qual Canal você deseja que vá as logs, Canal de Logs Atual: (${channel})`)
                ],
                components:[
                    new ActionRowBuilder()
                    .addComponents(
                        new ChannelSelectMenuBuilder()
                        .setCustomId(`${userid}_logsticketselect`)
                        .setPlaceholder("Escolha o Canal de Logs")
                        .setChannelTypes(ChannelType.GuildText)
                    ),
                    new ActionRowBuilder()
                    .addComponents(
                        new ButtonBuilder()
                        .setCustomId(`${userid}_removerlogsticket`)
                        .setStyle(4)
                        .setEmoji(emoji.lixeira)
                        .setLabel("Remover Canal De Logs")
                    ),
                    new ActionRowBuilder()
                    .addComponents(
                        new ButtonBuilder()
                        .setCustomId(`${userid}_configgeraisticket`)
                        .setLabel("Voltar")
                        .setStyle(2)
                        .setEmoji(emoji.voltar)
                    )
                ]
            })
        }

        if(customId.endsWith("_logsticketselect")) {
            const id = interaction.values[0];
            try {
                await ticket.tconfig.set("logs", id);
                await configgeraisticket(interaction, client);
            } catch (err){
                interaction.message.edit({content:`${emoji.nao} | Ocorreu um erro, use o comando novamente! \n\n Mensagem do Erro: ${err.message}`, embeds:[],components:[],files:[]});
            }
        }

        if(customId.endsWith("_removerlogsticket")) {
            try {
                await ticket.tconfig.set("logs", "Não Configurado");
                await configgeraisticket(interaction, client);
            } catch (err){
                interaction.message.edit({content:`${emoji.nao} | Ocorreu um erro, use o comando novamente! \n\n Mensagem do Erro: ${err.message}`, embeds:[],components:[],files:[]});
            }
        }

        if(customId.endsWith("_htmlticket")) {
            const channel = interaction.guild.channels.cache.get(await ticket.tconfig.get("logs_html")) || "`Não Configurado`";

            await interaction.update({
                embeds:[
                    new EmbedBuilder()
                    .setThumbnail(interaction.client.user.displayAvatarURL())
                    .setFooter({text:`${interaction.client.user.username} - Todos os Direitos Reservados`, iconURL: interaction.client.user.displayAvatarURL()})
                    .setTitle(`${interaction.guild.name} | Selecionar Canal de Logs-HTML`)
                    .setDescription(`${emoji.setadireita} Escolha qual Canal você deseja que vá as logs-HTML, Canal de Logs-HTML Atual: (${channel})`)
                ],
                components:[
                    new ActionRowBuilder()
                    .addComponents(
                        new ChannelSelectMenuBuilder()
                        .setCustomId(`${userid}_logshtmlticketselect`)
                        .setPlaceholder("Escolha o Canal de Logs-HTML")
                        .setChannelTypes(ChannelType.GuildText)
                    ),
                    new ActionRowBuilder()
                    .addComponents(
                        new ButtonBuilder()
                        .setCustomId(`${userid}_removerlogshtmlticket`)
                        .setStyle(4)
                        .setEmoji(emoji.lixeira)
                        .setLabel("Remover Canal De Logs")
                    ),
                    new ActionRowBuilder()
                    .addComponents(
                        new ButtonBuilder()
                        .setCustomId(`${userid}_configgeraisticket`)
                        .setLabel("Voltar")
                        .setStyle(2)
                        .setEmoji(emoji.voltar)
                    )
                ]
            })
        }

        if(customId.endsWith("_logshtmlticketselect")) {
            const id = interaction.values[0];
            try {
                await ticket.tconfig.set("logs_html", id);
                await configgeraisticket(interaction, client);
            } catch (err){
                interaction.message.edit({content:`${emoji.nao} | Ocorreu um erro, use o comando novamente! \n\n Mensagem do Erro: ${err.message}`, embeds:[],components:[],files:[]});
            }
        }

        if(customId.endsWith("_removerlogshtmlticket")) {
            try {
                await ticket.tconfig.set("logs_html", "Não Configurado");
                await configgeraisticket(interaction, client);
            } catch (err){
                interaction.message.edit({content:`${emoji.nao} | Ocorreu um erro, use o comando novamente! \n\n Mensagem do Erro: ${err.message}`, embeds:[],components:[],files:[]});
            }
        }


        if(customId.endsWith("_categoryticket")) {
            const channel = interaction.guild.channels.cache.get(await ticket.tconfig.get("category")) || "`Não Configurado`";

            await interaction.update({
                embeds:[
                    new EmbedBuilder()
                    .setThumbnail(interaction.client.user.displayAvatarURL())
                    .setFooter({text:`${interaction.client.user.username} - Todos os Direitos Reservados`, iconURL: interaction.client.user.displayAvatarURL()})
                    .setTitle(`${interaction.guild.name} | Selecionar Categoria Ticket`)
                    .setDescription(`${emoji.setadireita} Escolha qual categoria ira abrir os ticket, Nome da Categoria Atual: (${channel})`)
                ],
                components:[
                    new ActionRowBuilder()
                    .addComponents(
                        new ChannelSelectMenuBuilder()
                        .setCustomId(`${userid}_categoryticketselect`)
                        .setPlaceholder("Escolha a Categoria de Ticket")
                        .setChannelTypes(ChannelType.GuildCategory)
                    ),
                    new ActionRowBuilder()
                    .addComponents(
                        new ButtonBuilder()
                        .setCustomId(`${userid}_removercategoryticket`)
                        .setStyle(4)
                        .setEmoji(emoji.lixeira)
                        .setLabel("Remover Categoria Ticket")
                    ),
                    new ActionRowBuilder()
                    .addComponents(
                        new ButtonBuilder()
                        .setCustomId(`${userid}_configgeraisticket`)
                        .setLabel("Voltar")
                        .setStyle(2)
                        .setEmoji(emoji.voltar)
                    )
                ]
            })
        }

        if(customId.endsWith("_categoryticketselect")) {
            const id = interaction.values[0];
            try {
                await ticket.tconfig.set("category", id);
                await configgeraisticket(interaction, client);
            } catch (err){
                interaction.message.edit({content:`${emoji.nao} | Ocorreu um erro, use o comando novamente! \n\n Mensagem do Erro: ${err.message}`, embeds:[],components:[],files:[]});
            }
        }

        if(customId.endsWith("_removercategoryticket")) {
            try {
                await ticket.tconfig.set("category", "Não Configurado");
                await configgeraisticket(interaction, client);
            } catch (err){
                interaction.message.edit({content:`${emoji.nao} | Ocorreu um erro, use o comando novamente! \n\n Mensagem do Erro: ${err.message}`, embeds:[],components:[],files:[]});
            }
        }

        if(customId.endsWith("_roleticket")) {
            const channel = interaction.guild.roles.cache.get(await ticket.tconfig.get("role")) || "`Não Configurado`";

            await interaction.update({
                embeds:[
                    new EmbedBuilder()
                    .setThumbnail(interaction.client.user.displayAvatarURL())
                    .setFooter({text:`${interaction.client.user.username} - Todos os Direitos Reservados`, iconURL: interaction.client.user.displayAvatarURL()})
                    .setTitle(`${interaction.guild.name} | Selecionar Cargo Ticket`)
                    .setDescription(`${emoji.setadireita} Escolha qual cargo poderá ver os ticket, Cargo Atual: (${channel})`)
                ],
                components:[
                    new ActionRowBuilder()
                    .addComponents(
                        new RoleSelectMenuBuilder()
                        .setCustomId(`${userid}_cargoselect`)
                        .setPlaceholder("Escolha o Cargo de Staff")
                        .setMaxValues(1)
                    ),
                    new ActionRowBuilder()
                    .addComponents(
                        new ButtonBuilder()
                        .setCustomId(`${userid}_removerroleticket`)
                        .setStyle(4)
                        .setEmoji(emoji.lixeira)
                        .setLabel("Remover Cargo Staff")
                    ),
                    new ActionRowBuilder()
                    .addComponents(
                        new ButtonBuilder()
                        .setCustomId(`${userid}_configgeraisticket`)
                        .setLabel("Voltar")
                        .setStyle(2)
                        .setEmoji(emoji.voltar)
                    )
                ]
            })
        }

        if(customId.endsWith("_cargoselect")) {
            const id = interaction.values[0];
            try {
                await ticket.tconfig.set("role", id);
                await configgeraisticket(interaction, client);
            } catch (err){
                interaction.message.edit({content:`${emoji.nao} | Ocorreu um erro, use o comando novamente! \n\n Mensagem do Erro: ${err.message}`, embeds:[],components:[],files:[]});
            }
        }

        if(customId.endsWith("_removerroleticket")) {
            try {
                await ticket.tconfig.set("role", "Não Configurado");
                await configgeraisticket(interaction, client);
            } catch (err){
                interaction.message.edit({content:`${emoji.nao} | Ocorreu um erro, use o comando novamente! \n\n Mensagem do Erro: ${err.message}`, embeds:[],components:[],files:[]});
            }
        }

        if(customId.endsWith("_configembed")){
            try {
                await configembed(interaction, client);
            } catch (err){
                interaction.message.edit({content:`${emoji.nao} | Ocorreu um erro, use o comando novamente! \n\n Mensagem do Erro: ${err.message}`, embeds:[],components:[],files:[]});
            }
        }

        if(customId.endsWith("_embedfora")){
            try {
                await configembedfora(interaction, client);
            } catch (err){
                interaction.message.edit({content:`${emoji.nao} | Ocorreu um erro, use o comando novamente! \n\n Mensagem do Erro: ${err.message}`, embeds:[],components:[],files:[]});
            }
        }

        if(customId.endsWith("_resetembedfora")) {
            const modal = new ModalBuilder()
            .setCustomId(`${userid}_resetmodalfora`)
            .setTitle("💢 - Resetar Embed Fora");

            const text = new TextInputBuilder()
            .setCustomId("text")
            .setLabel("Digite SIM maiusculo")
            .setStyle(1)
            .setMaxLength(3)
            .setMinLength(3)
            .setRequired(true)
            .setPlaceholder("SIM");

            modal.addComponents(new ActionRowBuilder().addComponents(text));

            return interaction.showModal(modal);
        }

        if(customId.endsWith("_resetmodalfora")) {
            const text = interaction.fields.getTextInputValue("text");

            if(text !== "SIM") return interaction.reply({content:`${emoji.aviso} | Resetar Embed foi cancelado com sucesso`, ephemeral:true});
            await ticket.embed.set(`fora`, {
                "title":"#{guild} | Sistema Ticket",
                "description":"Para obter **SUPORTE** abra um ticket clicando no botão abaixo.",
                "footer":"remover",
                "banner":"remover",
                "button":{
                    "cor":2,
                    "label":"Abrir Ticket",
                    "emoji":"🎫"
                },
                "cor":"#000000"
            });
            
            await configembedfora(interaction, client);

        }

        if(customId.endsWith("_tituloembedfora")) {
            const modal = new ModalBuilder()
            .setCustomId(`${userid}_tituloembedforamodal`)
            .setTitle("💢 - Alterar Titulo da Embed");

            const text = new TextInputBuilder()
            .setCustomId("text")
            .setLabel("Coloque o Novo Titulo")
            .setMaxLength(45)
            .setMinLength(2)
            .setRequired(true)
            .setStyle(1);

            modal.addComponents(new ActionRowBuilder().addComponents(text));
            
            return interaction.showModal(modal);
        }

        if(customId.endsWith("_tituloembedforamodal")) {
            const text = interaction.fields.getTextInputValue("text");
            await ticket.embed.set(`fora.title`, text);
            await configembedfora(interaction, client);
        } //

        if(customId.endsWith("_descembedfora")) {
            const modal = new ModalBuilder()
            .setCustomId(`${userid}_descembedforamodal`)
            .setTitle("💢 - Alterar Descrição da Embed");

            const text = new TextInputBuilder()
            .setCustomId("text")
            .setLabel("Coloque a nova descrição:")
            .setMinLength(2)
            .setRequired(true)
            .setStyle(2);

            modal.addComponents(new ActionRowBuilder().addComponents(text));
            
            return interaction.showModal(modal);
        }

        if(customId.endsWith("_descembedforamodal")) {
            const text = interaction.fields.getTextInputValue("text");
            await ticket.embed.set(`fora.description`, text);
            await configembedfora(interaction, client);
        } //

        if(customId.endsWith("_footerembedfora")) {
            const modal = new ModalBuilder()
            .setCustomId(`${userid}_footerembedforamodal`)
            .setTitle("💢 - Alterar footer da Embed");

            const text = new TextInputBuilder()
            .setCustomId("text")
            .setLabel("Coloque o Novo Rodapé")
            .setMaxLength(45)
            .setPlaceholder("Caso deseja remover Digite: \"remover\"")
            .setMinLength(2)
            .setRequired(true)
            .setStyle(1);

            modal.addComponents(new ActionRowBuilder().addComponents(text));
            
            return interaction.showModal(modal);
        }

        if(customId.endsWith("_footerembedforamodal")) {
            const text = interaction.fields.getTextInputValue("text");
            await ticket.embed.set(`fora.footer`, text);
            await configembedfora(interaction, client);
        } //

        if(customId.endsWith("_bannerembedfora")) {
            const modal = new ModalBuilder()
            .setCustomId(`${userid}_bannnerembedforamodal`)
            .setTitle("💢 - Alterar banner da Embed");

            const text = new TextInputBuilder()
            .setCustomId("text")
            .setLabel("Coloque o Novo banner")
            .setPlaceholder("Digite 'remover' para tirar o banner")
            .setRequired(true)
            .setStyle(1);

            modal.addComponents(new ActionRowBuilder().addComponents(text));
            
            return interaction.showModal(modal);
        }

        if(customId.endsWith("_bannnerembedforamodal")) {
            const text = interaction.fields.getTextInputValue("text");
            if(text === "remover") {
                await ticket.embed.set(`fora.banner`, text);
                configembedforaedit(interaction,client)
                return;
            }
            try {
                await configembedfora(interaction, client).then(() => {
                    ticket.embed.set(`fora.banner`, text);
                    configembedforaedit(interaction,client)
                })
            } catch {
                await interaction.reply({content:`${emoji.aviso} | Coloque uma imagem valida!`, ephemeral:true});
            }
        } //

        if(customId.endsWith("_corembed")) {
            const modal = new ModalBuilder()
            .setCustomId(`${userid}_corembedforamodal`)
            .setTitle("💢 - Alterar Cor da Embed");

            const text = new TextInputBuilder()
            .setCustomId("text")
            .setLabel("Coloque uma cor hexadecimal:")
            .setPlaceholder("#000000")
            .setRequired(true)
            .setStyle(1);

            modal.addComponents(new ActionRowBuilder().addComponents(text));
            
            return interaction.showModal(modal);
        }

        if(customId.endsWith("_corembedforamodal")) {
            const text = interaction.fields.getTextInputValue("text");
            try {
                await configembedfora(interaction, client).then(()=> {
                    ticket.embed.set(`fora.cor`, text);
                    configembedforaedit(interaction,client)
                });
            } catch {
                await interaction.reply({content:`${emoji.aviso} | Coloque uma cor hexadecimal valida!`, ephemeral:true});
            }
        }

        if(customId.endsWith("_buttonembedfora")) {
            await buttonembedfora(interaction, client);
        }

        if(customId.endsWith("_alterartextbutton")) {
            const modal = new ModalBuilder()
            .setCustomId(`${userid}_alterarlabelbuttonmodal`)
            .setTitle("💢 - Alterar Texto Botão");

            const text = new TextInputBuilder()
            .setCustomId("text")
            .setLabel("COLOQUE O NOVO TEXTO:")
            .setStyle(1)
            .setMaxLength(35)
            .setRequired(true)
            .setPlaceholder("Abrir Ticket");

            modal.addComponents(new ActionRowBuilder().addComponents(text));

            return interaction.showModal(modal);
        }

        if(customId.endsWith("_alterarlabelbuttonmodal")) {
            const text = interaction.fields.getTextInputValue("text");

            try {
                await ticket.embed.set(`fora.button.label`, text);
                await buttonembedfora(interaction, client);
            } catch (err){
                interaction.reply({content:`${emoji.aviso} | Ocorreu um erro... \n\n Mensagem do Erro: ${err.message}`, ephemeral:true})
            }
        }

        if(customId.endsWith("_alteraremojibutton")) {
           await interaction.update({
                embeds: [
                  new EmbedBuilder()
                    .setTitle(`${interaction.client.user.username} | Alterar Emoji da Embed Fora`)
                    .setDescription(`${emoji.setadireita} | Envie o Emoji abaixo: \n ** O emoji tem que estar em um server que o bot também está!**`)
                ],
                components: [
                  new ActionRowBuilder()
                    .addComponents(
                      new ButtonBuilder()
                        .setCustomId(`${userid}_cancelled`)
                        .setLabel("Cancelar")
                        .setEmoji(emoji.nao)
                        .setStyle(4)
                    )
                ]
              });
            
const filterMensagem = (msg) => msg.author.id === interaction.user.id;
const collectorMensagem = interaction.channel.createMessageCollector({ filter: filterMensagem });


collectorMensagem.on("collect", async (mensagem) => {
  await mensagem.delete();
  collectorMensagem.stop();
  const emojis = mensagem.content;
    
      const emojiverification = interaction.client.emojis.cache.find(emoji => `<:${emoji.name}:${emoji.id}>` === emojis) || interaction.client.emojis.cache.find(emoji => emoji.name === emojis) || interaction.client.emojis.cache.get(emojis);

      function emojiverification2(str) {
        const customEmojiRegex = /<a?:\w+:\d+>/g; 
const unicodeEmojiRegex = /[\uD83C-\uDBFF\uDC00-\uDFFF\u2600-\u26FF\u2700-\u27BF]/g; 
const animatedEmojiRegex = /<a:\w+:\d+>/g; 
      
        const customEmojiMatches = str.match(customEmojiRegex) || [];
        const unicodeEmojiMatches = str.match(unicodeEmojiRegex) || [];
        const animatedEmojiMatches = str.match(animatedEmojiRegex) || [];
      
        const totalEmojiCount = customEmojiMatches.length + unicodeEmojiMatches.length + animatedEmojiMatches.length;
      
        return totalEmojiCount === 1;
      } 

        if (!emojiverification && !emojiverification2(`${emojis}`)) {
           await interaction.followUp({
              ephemeral:true,
               content:`❌ | Coloque um emoji Valido!`
              })
              await buttonembedforaedit(interaction, client);
            return;
        }  
        await ticket.embed.set(`fora.button.emoji`, emojis);
        await buttonembedforaedit(interaction, client);
  
});


const filterBotao = (i) => i.customId.startsWith(userid) && i.customId.endsWith("_cancelled") && i.user.id === interaction.user.id;
const collectorBotao = interaction.channel.createMessageComponentCollector({ filter: filterBotao});


collectorBotao.on("collect", (i) => {
  collectorMensagem.stop();
  collectorBotao.stop("cancelled");
  i.deferUpdate();
  buttonembedforaedit(interaction, client); 
});

        }

        if(customId.endsWith("_alterarcolorbutton")) {
            interaction.update({
                embeds:[
                    new EmbedBuilder()
                    .setDescription(`${emoji.setadireita} Escolha qual cor você deseja`)
                ],
                components:[
                    new ActionRowBuilder()
                    .addComponents(
                        new ButtonBuilder()
                        .setCustomId(`${userid}_corazulfora`)
                        .setLabel("Azul")
                        .setStyle(1),
                        new ButtonBuilder()
                        .setCustomId(`${userid}_corcinzafora`)
                        .setLabel("Cinza")
                        .setStyle(2),
                        new ButtonBuilder()
                        .setCustomId(`${userid}_corverdefora`)
                        .setLabel("Verde")
                        .setStyle(3),
                        new ButtonBuilder()
                        .setCustomId(`${userid}_corvermelhofora`)
                        .setLabel("Vermelho")
                        .setStyle(4),
                        new ButtonBuilder()
                        .setCustomId(`${userid}_buttonembedfora`)
                        .setLabel("Voltar")
                        .setEmoji(emoji.voltar)
                        .setStyle(2),
                    )
                ]
            })
        }

        if(customId.endsWith("_corazulfora")) {
            await ticket.embed.set("fora.button.cor", 1);
            await buttonembedfora(interaction, client);
        }
        if(customId.endsWith("_corcinzafora")) {
            await ticket.embed.set("fora.button.cor", 2);
            await buttonembedfora(interaction, client);
        }
        if(customId.endsWith("_corverdefora")) {
            await ticket.embed.set("fora.button.cor", 3);
            await buttonembedfora(interaction, client);
        }
        if(customId.endsWith("_corvermelhofora")) {
            await ticket.embed.set("fora.button.cor", 4);
            await buttonembedfora(interaction, client);
        }

        if(customId.endsWith("_embeddentro")) {
            try {
                await configembeddentro(interaction,client);
            } catch (err) {
                await interaction.message.edit({content:`${emoji.aviso} Ocorreu um erro... \n\n Erro da Mensagem: ${err.message}`, embeds:[], components:[],files:[]});
            }
        }

        if(customId.endsWith("_titleembeddentro")) {
            await interaction.update({
                embeds: [
                  new EmbedBuilder()
                    .setTitle(`${interaction.client.user.username} | Alterar Titulo Embed`)
                    .setFooter({text:"Lembrando, as Variaveis não são obrigatorias!"})
                    .setDescription(`${emoji.setadireita} | Envie o novo titulo da embed do ticket, caso queira use as váriaveis:\n- \`#{username}\` - Nome do Usuario\n - \`#{userid}\` - ID do Usuario \n\n- \`#{horarios.dia}\` - Horario em Dias \n - \`#{horarios.horas}\` - Horario em Horas \n\n- \`#{motivo}\` - Motivo do Ticket \n - \`#{codigo}\` - Codigo do Ticket`)
                ],
                components: [
                  new ActionRowBuilder()
                    .addComponents(
                      new ButtonBuilder()
                        .setCustomId(`${userid}_cancelled`)
                        .setLabel("Cancelar")
                        .setEmoji(emoji.nao)
                        .setStyle(4)
                    )
                ]
              });
            
const filterMensagem = (msg) => msg.author.id === interaction.user.id;
const collectorMensagem = interaction.channel.createMessageCollector({ filter: filterMensagem });


collectorMensagem.on("collect", async (mensagem) => {
  await mensagem.delete();
  collectorMensagem.stop();
  const emojis = mensagem.content;
  const titleold = await ticket.embed.get(`dentro.title`);
    
        try {
            await ticket.embed.set(`dentro.title`, emojis);
            await configembeddentroedit(interaction,client)
        } catch {
            interaction.channel.send({
                content:`${emoji.aviso} | Ocorreu um erro ao tentar colocar esse titulo, Recomendo Diminuir!`
            }).then((msg) => {
                setTimeout(() => {
                    msg.delete()
                }, 2700);
            })
            await ticket.embed.set(`dentro.title`, titleold);
            await configembeddentroedit(interaction,client)
        }
});


const filterBotao = (i) => i.customId.startsWith(userid) && i.customId.endsWith("_cancelled") && i.user.id === interaction.user.id;
const collectorBotao = interaction.channel.createMessageComponentCollector({ filter: filterBotao});


collectorBotao.on("collect", (i) => {
  collectorMensagem.stop();
  collectorBotao.stop("cancelled");
  i.deferUpdate();
  configembeddentroedit(interaction,client);
});
        }

        if(customId.endsWith("_descembeddentro")) {
            await interaction.update({
                embeds: [
                  new EmbedBuilder()
                    .setTitle(`${interaction.client.user.username} | Alterar Descrição Embed`)
                    .setFooter({text:"Lembrando, as Variaveis não são obrigatorias!"})
                    .setImage("https://media.discordapp.net/attachments/1192881702679359549/1196887442620436500/image.png?ex=65b9434b&is=65a6ce4b&hm=aa4609bab789c549dceeb6c22fa88e86cfa418e6244f311ff87bd122b7c2c762&=&format=webp&quality=lossless&width=403&height=186")
                    .setDescription(`${emoji.setadireita} | Envie a nova descrição da embed do ticket, caso queira use as váriaveis:\n- \`#{username}\` - Nome do Usuario\n - \`#{user}\` - Marcar o Usuario \n - \`#{userid}\` - ID do Usuario \n\n- \`#{horarios.dia}\` - Horario em Dias \n - \`#{horarios.horas}\` - Horario em Horas \n\n- \`#{motivo}\` - Motivo do Ticket \n - \`#{codigo}\` - Codigo do Ticket \n\n ${emoji.setadireita} Segue o **Exemplo** Abaixo`)
                ],
                components: [
                  new ActionRowBuilder()
                    .addComponents(
                      new ButtonBuilder()
                        .setCustomId(`${userid}_cancelled`)
                        .setLabel("Cancelar")
                        .setEmoji(emoji.nao)
                        .setStyle(4)
                    )
                ]
              });
            
const filterMensagem = (msg) => msg.author.id === interaction.user.id;
const collectorMensagem = interaction.channel.createMessageCollector({ filter: filterMensagem });


collectorMensagem.on("collect", async (mensagem) => {
  await mensagem.delete();
  collectorMensagem.stop();
  const emojis = mensagem.content;
  const titleold = await ticket.embed.get(`dentro.description`);
    
        try {
            await ticket.embed.set(`dentro.description`, emojis);
            await configembeddentroedit(interaction,client)
        } catch {
            interaction.channel.send({
                content:`${emoji.aviso} | Ocorreu um erro ao tentar colocar essa descrição, Recomendo Diminuir!`
            }).then((msg) => {
                setTimeout(() => {
                    msg.delete()
                }, 2700);
            })
            await ticket.embed.set(`dentro.description`, titleold);
            await configembeddentroedit(interaction,client)
        }
});


const filterBotao = (i) => i.customId.startsWith(userid) && i.customId.endsWith("_cancelled") && i.user.id === interaction.user.id;
const collectorBotao = interaction.channel.createMessageComponentCollector({ filter: filterBotao});


collectorBotao.on("collect", (i) => {
  collectorMensagem.stop();
  collectorBotao.stop("cancelled");
  i.deferUpdate();
  configembeddentroedit(interaction,client);
});
        }

        if(customId.endsWith("_footerembeddentro")){
            const modal = new ModalBuilder()
            .setCustomId(`${userid}_footerdentromodal`)
            .setTitle("💢 - Alterar Footer");

            const text = new TextInputBuilder()
            .setCustomId("text")
            .setLabel("Coloque o Novo footer:")
            .setPlaceholder('Caso Deseja Remover digite: "remover"')
            .setStyle(1)
            .setMaxLength(36)
            .setRequired(true);

            modal.addComponents(new ActionRowBuilder().addComponents(text));

            return interaction.showModal(modal);
        }

        if(customId.endsWith("_footerdentromodal")) {
            const text = interaction.fields.getTextInputValue("text");
            try {
                await ticket.embed.set("dentro.footer", text);
                await configembeddentro(interaction,client)
            } catch(err) {
                interaction.message.edit({content:`${emoji.aviso} | Ocorreu um erro ao tentar resetar... \n\n Mensagem do Erro: ${err.message}`, components:[], embeds:[], files:[]});
            }
        }

        if(customId.endsWith("_bannerembeddentro")) {
            const modal = new ModalBuilder()
            .setCustomId(`${userid}_bannermodaldentro`)
            .setTitle("💢 - Alterar Banner Embed");

            const text = new TextInputBuilder()
            .setCustomId(`text`)
            .setLabel("Coloque a URL do Banner:")
            .setPlaceholder("Digite: \"remover\" para remover o banner")
            .setStyle(1)
            .setRequired(true);

            modal.addComponents(new ActionRowBuilder().addComponents(text));

            return interaction.showModal(modal);
        }

        if(customId.endsWith("_bannermodaldentro")) {
            const text = interaction.fields.getTextInputValue("text");
            if(text === "remover") {
                try {
                    await ticket.embed.set("dentro.banner", text);
                    await configembeddentro(interaction,client)
                } catch(err) {
                    interaction.message.edit({content:`${emoji.aviso} | Ocorreu um erro ao tentar resetar... \n\n Mensagem do Erro: ${err.message}`, components:[], embeds:[], files:[]});
                }
            } else {
                if(!text.startsWith("https://")) return interaction.reply({content:`${emoji.aviso} | Coloque uma URL Valida!`, ephemeral:true});
                const old = await ticket.embed.get("dentro.banner");
                try {
                    await ticket.embed.set("dentro.banner", text);
                    await configembeddentro(interaction,client)
                } catch(err) {
                    interaction.reply({content:`${emoji.aviso} | Coloque uma imagem Valida`, ephemeral:true});
                    await ticket.embed.set("dentro.banner", old);
                    await configembeddentroedit(interaction,client)
                }
            }

        }

        if(customId.endsWith("_corembeddentro123")) {
            const modal = new ModalBuilder()
            .setCustomId(`${userid}_corembeddentro123modal`)
            .setTitle("💢 - Alterar Cor Embed");

            const text = new TextInputBuilder()
            .setCustomId(`text`)
            .setLabel("Coloque a Cor da embed:")
            .setPlaceholder("#000000")
            .setStyle(1)
            .setRequired(true);

            modal.addComponents(new ActionRowBuilder().addComponents(text));

            return interaction.showModal(modal);
        }

        if(customId.endsWith("_corembeddentro123modal")) {
            const text = interaction.fields.getTextInputValue("text");
            const old = await ticket.embed.get("dentro.cor");
            try {
                await ticket.embed.set("dentro.cor", text);
                await configembeddentro(interaction,client);
            } catch(err) {
                interaction.reply({content:`${emoji.aviso} | Coloque uma Cor Valida`, ephemeral:true});
                await ticket.embed.set("dentro.cor", old);
                await configembeddentroedit(interaction,client);
            }
        }


        if(customId.endsWith("_resetembeddentro")) {
            await interaction.reply({content:`${emoji.loading} | Aguarde um momento...`, ephemeral:true});
            try {
                await ticket.embed.set("dentro", {
                    "title": "#{username} | TICKET",
                    "description": "Olá #{user}, Seja Bem Vindo ao ticket ao seu Ticket! \n\n 👥** | Usuario:** #{user} - `#{username} (#{userid})` \n\n ⏰** | Horario:** #{horarios.dia} (#{horarios.horas}) \n\n 🔎 **| Motivo do Ticket:** #{motivo} \n\n📝** Codigo do Ticket:** #{codigo}",
                    "footer": "remover",
                    "banner": "remover",
                    "cor":"#000000"
                });
                await configembeddentroedit(interaction,client)
                await interaction.editReply({content:`${emoji.sim} | Configurações Resetadas com sucesso!`});
                
            } catch(err) {
                interaction.editReply({content:`${emoji.aviso} | Ocorreu um erro ao tentar resetar... \n\n Mensagem do Erro: ${err.message}`});
            }
        }

    }
}