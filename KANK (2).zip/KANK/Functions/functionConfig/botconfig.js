const { ApplicationCommandType, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ModalBuilder, TextInputBuilder } = require("discord.js");
const vendas = require("../../DataBase/vindex");
const ticket = require("../../DataBase/tindex");
const emoji = require("../../DataBase/emojis.json");
const owner = require("../../DataBase/owner.json");

async function configvendasedit(interaction, client) {
    const customId = interaction.customId;
    const userid = customId.split("_")[0];
    await interaction.message.edit({
        embeds:[
            new EmbedBuilder()
            .setTitle(`${interaction.guild.name} | Configurar Sistema de Vendas`)
            .setThumbnail(interaction.client.user.displayAvatarURL())
            .setFooter({text:`${interaction.client.user.username} - Todos os Direitos Reservados`, iconURL: interaction.client.user.displayAvatarURL()})
            .setDescription(`${emoji.engrenagem} | Sistema de Vendas: ${await vendas.vconfig.get("vendasonoff") ? "`Sistema Está Ligado!`" : "`Sistema Está Desativado!`"} \n\n **Caso você queira me adicionar em outro servidor Clique no Link:** [Clique Aqui](https://discord.com/api/oauth2/authorize?client_id=${interaction.client.user.id}&permissions=8&scope=bot%20applications.commands)`)
        ],
        components:[
            new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                .setCustomId(`${interaction.user.id}_sistemadevendasonoff`)
                .setLabel("Vendas ON/OFF")
                .setEmoji(emoji.engrenagem)
                .setStyle(await vendas.vconfig.get("vendasonoff") ? 3 : 4),
                new ButtonBuilder()
                .setCustomId(`${userid}_configpayments`)
                .setLabel("Configurar Pagamentos")
                .setStyle(1)
                .setEmoji(emoji.maoapertado),
                new ButtonBuilder()
                .setCustomId(`${userid}_configchannel`)
                .setLabel("Configurar Canais")
                .setStyle(1)
                .setEmoji(emoji.envelope),
                new ButtonBuilder()
                .setCustomId(`${userid}_configterms`)
                .setLabel("Configurar Termos")
                .setStyle(1)
                .setEmoji(emoji.prancheta)
            ),
            new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                .setCustomId(`${userid}_voltarconfigvendas`)
                .setLabel("Voltar")
                .setStyle(2)
                .setEmoji(emoji.voltar)
            )
        ]
    })
}
async function configvendas(interaction, client) {
    const customId = interaction.customId;
    const userid = customId.split("_")[0];
    await interaction.update({
        embeds:[
            new EmbedBuilder()
            .setTitle(`${interaction.guild.name} | Configurar Sistema de Vendas`)
            .setThumbnail(interaction.client.user.displayAvatarURL())
            .setFooter({text:`${interaction.client.user.username} - Todos os Direitos Reservados`, iconURL: interaction.client.user.displayAvatarURL()})
            .setDescription(`${emoji.engrenagem} | Sistema de Vendas: ${await vendas.vconfig.get("vendasonoff") ? "`Sistema Está Ligado!`" : "`Sistema Está Desativado!`"} \n\n **Caso você queira me adicionar em outro servidor Clique no Link:** [Clique Aqui](https://discord.com/api/oauth2/authorize?client_id=${interaction.client.user.id}&permissions=8&scope=bot%20applications.commands)`)
        ],
        components:[
            new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                .setCustomId(`${interaction.user.id}_sistemadevendasonoff`)
                .setLabel("Vendas ON/OFF")
                .setEmoji(emoji.engrenagem)
                .setStyle(await vendas.vconfig.get("vendasonoff") ? 3 : 4),
                new ButtonBuilder()
                .setCustomId(`${userid}_configpayments`)
                .setLabel("Configurar Pagamentos")
                .setStyle(1)
                .setEmoji(emoji.maoapertado),
                new ButtonBuilder()
                .setCustomId(`${userid}_configchannel`)
                .setLabel("Configurar Canais")
                .setStyle(1)
                .setEmoji(emoji.envelope),
                new ButtonBuilder()
                .setCustomId(`${userid}_configterms`)
                .setLabel("Configurar Termos")
                .setStyle(1)
                .setEmoji(emoji.prancheta)
            ),
            new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                .setCustomId(`${userid}_voltarconfigvendas`)
                .setLabel("Voltar")
                .setStyle(2)
                .setEmoji(emoji.voltar)
            )
        ]
    })
}

async function botconfig(interaction, client) {
    const customId = interaction.customId;
    const userid = customId.split("_")[0];
    await interaction.update({
        embeds:[
            new EmbedBuilder()
            .setTitle(`${interaction.guild.name} | Sistema de Configurações Gerais`)
            .setThumbnail(interaction.client.user.displayAvatarURL())
            .setFooter({text:`${interaction.client.user.username} - Todos os Direitos Reservados`, iconURL: interaction.client.user.displayAvatarURL()})
            .setDescription(`Olá ***${interaction.user.username}***, Seja Bem Vindo ao painel de configuração, escolha abaixo qual opção você deseja configurar`)
        ],
        components:[
            new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                .setCustomId(`${interaction.user.id}_configvendas`)
                .setLabel("Configurar Vendas")
                .setStyle(1)
                .setEmoji("🤑"),
                new ButtonBuilder()
                .setCustomId(`${interaction.user.id}_configticket`)
                .setLabel("Configurar Ticket")
                .setStyle(1)
                .setEmoji("🎫")
            )
        ]
    })
}

async function configpayments(interaction, client) {
    const customId = interaction.customId;
    const userid = customId.split("_")[0];
    await interaction.update({
        content:"",
        embeds:[
            new EmbedBuilder()
            .setTitle(`${interaction.guild.name} | Configuração de Pagamentos`)
            .setThumbnail(interaction.client.user.displayAvatarURL())
            .setFooter({text:`${interaction.client.user.username} - Todos os Direitos Reservados`, iconURL: interaction.client.user.displayAvatarURL()})
            .setDescription(`${emoji.bagmoney} | Configure o sistema de Pagamento`)
        ],
        components: [
            new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                .setCustomId(`${userid}_mercadopago`)
                .setLabel("Mercado Pago")
                .setStyle(1)
                .setEmoji(emoji.mercadopago),
                new ButtonBuilder()
                .setCustomId(`${userid}_configvendas`)
                .setLabel("Voltar")
                .setStyle(1)
                .setEmoji(emoji.voltar)
            )
        ]
    })

}

async function configmercadopago(interaction, client) {
    const customId = `${interaction.customId}`;
    const userid = customId.split("_")[0];

    await interaction.update({
        embeds:[
            new EmbedBuilder()
            .setThumbnail(interaction.client.user.displayAvatarURL())
            .setFooter({text:`${interaction.client.user.username} - Todos os Direitos Reservados`, iconURL: interaction.client.user.displayAvatarURL()})
            .setTitle(`${interaction.guild.name} | Configar mercado Pago`)
            .setDescription(`${emoji.corrente} | Pix: ${await vendas.vconfig.get("pix") ? "Pix Ativado" : "Pix Desativado"} \n ${emoji.corrente} | QRCode: ${await vendas.vconfig.get("qrcode") ? "QrCode Ativado" : "QrCode Desativado"} \n ${emoji.maoapertado} | Pagar pelo Site: ${await vendas.vconfig.get("siteonoff") ? "Site Ativado" : "Site Desativado"} \n${emoji.despertador} | Tempo para Pagar: ${await vendas.vconfig.get("tempopagar")} \n${emoji.engrenagem} | Acess Token: ||${vendas.vconfig.get("mp")}||`)
        ],
        components:[
            new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                .setCustomId(`${userid}_pixonoff`)
                .setLabel("Pix ON/OFF")
                .setStyle(await vendas.vconfig.get("pix") ? 3 : 4)
                .setEmoji(emoji.pix),
                new ButtonBuilder()
                .setCustomId(`${userid}_qrcode`)
                .setStyle(await vendas.vconfig.get("qrcode") ? 3 : 4)
                .setLabel("QrCode ON/OFF")
                .setEmoji(emoji.qrcode),
                new ButtonBuilder()
                .setCustomId(`${userid}_siteonoff`)
                .setStyle(await vendas.vconfig.get("siteonoff") ? 3 : 4)
                .setLabel("Pagar no Site ON/OFF")
                .setEmoji(emoji.envelope),
                new ButtonBuilder()
                .setCustomId(`${userid}_tempopagar`)
                .setStyle(2)
                .setLabel("Tempo para Pagar")
                .setEmoji(emoji.despertador),
                new ButtonBuilder()
                .setCustomId(`${userid}_acesstoken`)
                .setStyle(2)
                .setLabel("Alterar Acess Token")
                .setEmoji(emoji.mercadopago),
            ),
            new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                .setCustomId(`${userid}_configpayments`)
                .setLabel("Voltar")
                .setStyle(2)
                .setEmoji(emoji.voltar)
            )
        ]
    })

}

async function configmercadopagoedit(interaction, client) {
    const customId = `${interaction.customId}`;
    const userid = customId.split("_")[0];

    await interaction.message.edit({
        embeds:[
            new EmbedBuilder()
            .setThumbnail(interaction.client.user.displayAvatarURL())
            .setFooter({text:`${interaction.client.user.username} - Todos os Direitos Reservados`, iconURL: interaction.client.user.displayAvatarURL()})
            .setTitle(`${interaction.guild.name} | Configar mercado Pago`)
            .setDescription(`${emoji.corrente} | Pix: ${await vendas.vconfig.get("pix") ? "Pix Ativado" : "Pix Desativado"} \n ${emoji.corrente} | QRCode: ${await vendas.vconfig.get("qrcode") ? "QrCode Ativado" : "QrCode Desativado"} \n ${emoji.maoapertado} | Pagar pelo Site: ${await vendas.vconfig.get("siteonoff") ? "Site Ativado" : "Site Desativado"} \n${emoji.despertador} | Tempo para Pagar: ${await vendas.vconfig.get("tempopagar")} \n${emoji.engrenagem} | Acess Token: ||${vendas.vconfig.get("mp")}||`)
        ],
        components:[
            new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                .setCustomId(`${userid}_pixonoff`)
                .setLabel("Pix ON/OFF")
                .setStyle(await vendas.vconfig.get("pix") ? 3 : 4)
                .setEmoji(emoji.pix),
                new ButtonBuilder()
                .setCustomId(`${userid}_qrcode`)
                .setStyle(await vendas.vconfig.get("qrcode") ? 3 : 4)
                .setLabel("QrCode ON/OFF")
                .setEmoji(emoji.qrcode),
                new ButtonBuilder()
                .setCustomId(`${userid}_siteonoff`)
                .setStyle(await vendas.vconfig.get("siteonoff") ? 3 : 4)
                .setLabel("Pagar no Site ON/OFF")
                .setEmoji(emoji.envelope),
                new ButtonBuilder()
                .setCustomId(`${userid}_tempopagar`)
                .setStyle(2)
                .setLabel("Tempo para Pagar")
                .setEmoji(emoji.despertador),
                new ButtonBuilder()
                .setCustomId(`${userid}_acesstoken`)
                .setStyle(2)
                .setLabel("Alterar Acess Token")
                .setEmoji(emoji.mercadopago),
            ),
            new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                .setCustomId(`${userid}_configpayments`)
                .setLabel("Voltar")
                .setStyle(2)
                .setEmoji(emoji.voltar)
            )
        ]
    })

}

async function configchannels(interaction, client) {
    const customId = `${interaction.customId}`;
    const userid = customId.split("_")[0];

    await interaction.update({
        embeds:[
            new EmbedBuilder()
            .setThumbnail(interaction.client.user.displayAvatarURL())
            .setFooter({text:`${interaction.client.user.username} - Todos os Direitos Reservados`, iconURL: interaction.client.user.displayAvatarURL()})
            .setTitle(`${interaction.guild.name} | Configurações de Canais`)
            .setDescription(`${emoji.setadireita} Escolha Qual Canal você deseja alterar`)
        ],
        components:[
            new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                .setCustomId(`${userid}_configchannelpublic`)
                .setLabel("Configurar Canal Publico")
                .setStyle(1)
                .setEmoji(emoji.engrenagem),
                new ButtonBuilder()
                .setCustomId(`${userid}_configchannelstaff`)
                .setLabel("Configurar Canal Staff")
                .setStyle(1)
                .setEmoji(emoji.engrenagem),
                new ButtonBuilder()
                .setCustomId(`${userid}_configcategory`)
                .setLabel("Configurar Categoria Carrinho")
                .setStyle(1)
                .setEmoji(emoji.engrenagem),
                new ButtonBuilder()
                .setCustomId(`${userid}_configrolecliente`)
                .setLabel("Configurar Cargo Cliente")
                .setStyle(1)
                .setEmoji(emoji.engrenagem),
            ),
            new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                .setCustomId(`${userid}_configvendas`)
                .setLabel("Voltar")
                .setEmoji(emoji.voltar)
                .setStyle(2)
            )
        ]
    })

}

async function configticket(interaction, client) {
    const customId = interaction.customId;
    const userid = customId.split("_")[0];

    await interaction.update({
        embeds:[
            new EmbedBuilder()
            .setThumbnail(interaction.client.user.displayAvatarURL())
            .setFooter({text:`${interaction.client.user.username} - Todos os Direitos Reservados`, iconURL: interaction.client.user.displayAvatarURL()})
            .setTitle(`${interaction.guild.name} | Configurar Ticket`)
            .setDescription(`${emoji.engrenagem} | Sistema de Ticket: ${ticket.tconfig.get("ticketonoff") ? "`O Ticket está Ativado`" : "`O Ticket está Desativado`"} \n\n **Caso você queira me adicionar em outro servidor Clique no Link:** [Clique Aqui](https://discord.com/api/oauth2/authorize?client_id=${interaction.client.user.id}&permissions=8&scope=bot%20applications.commands)`)
        ],
        components:[
            new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                .setCustomId(`${userid}_ativarticket`)
                .setLabel("Sistema Ticket ON/OFF")
                .setStyle(ticket.tconfig.get("ticketonoff") ? 3 : 4)
                .setEmoji(emoji.ticket),
                new ButtonBuilder()
                .setCustomId(`${userid}_configgeraisticket`)
                .setLabel("Configurações Gerais")
                .setEmoji(emoji.engrenagem)
                .setStyle(1),
                new ButtonBuilder()
                .setCustomId(`${userid}_configembed`)
                .setLabel("Configurar Embed")
                .setEmoji(emoji.prancheta)
                .setStyle(1),
            ),
            new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                .setCustomId(`${userid}_voltarconfigvendas`)
                .setLabel("Voltar")
                .setStyle(2)
                .setEmoji(emoji.voltar)
            )
        ]
    })

}

async function configgeraisticket(interaction,client) {
    const customId = interaction.customId;
    const userid = customId.split("_")[0];
    await interaction.update({
        embeds:[
            new EmbedBuilder()
            .setThumbnail(interaction.client.user.displayAvatarURL())
            .setFooter({text:`${interaction.client.user.username} - Todos os Direitos Reservados`, iconURL: interaction.client.user.displayAvatarURL()})
            .setTitle(`${interaction.guild.name} | Configurações Gerais - Ticket`)
            .setDescription(`${emoji.setadireita} Selecione Qual das Configurações você deseja alterar`)
        ],
        components:[
            new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                .setCustomId(`${userid}_logsticket`)
                .setLabel("Configurar Canal de Logs")
                .setStyle(1)
                .setEmoji(emoji.engrenagem),
                new ButtonBuilder()
                .setCustomId(`${userid}_htmlticket`)
                .setLabel("Configurar Canal de Logs HTML")
                .setStyle(1)
                .setEmoji(emoji.engrenagem),
                new ButtonBuilder()
                .setCustomId(`${userid}_categoryticket`)
                .setLabel("Configurar Categoria")
                .setStyle(1)
                .setEmoji(emoji.engrenagem),
                new ButtonBuilder()
                .setCustomId(`${userid}_roleticket`)
                .setLabel("Configurar Cargo Staff")
                .setStyle(1)
                .setEmoji(emoji.engrenagem),
            ),
            new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                .setCustomId(`${userid}_configticket`)
                .setLabel("Voltar")
                .setStyle(2)
                .setEmoji(emoji.voltar)
            )
        ]
    })


}


async function configembed(interaction, client) {
    const customId = interaction.customId;
    const userid = customId.split("_")[0];

    await interaction.update({
        embeds:[
            new EmbedBuilder()
            .setThumbnail(interaction.client.user.displayAvatarURL())
            .setFooter({text:`${interaction.client.user.username} - Todos os Direitos Reservados`, iconURL: interaction.client.user.displayAvatarURL()})
            .setTitle(`${interaction.guild.name} | Configurar Embed Ticket`)
        ],
        components:[
            new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                .setCustomId(`${userid}_embedfora`)
                .setLabel("Configurar Embed Fora")
                .setStyle(1)
                .setEmoji(emoji.engrenagem),
                new ButtonBuilder()
                .setCustomId(`${userid}_embeddentro`)
                .setLabel("Configurar Embed Dentro")
                .setStyle(1)
                .setEmoji(emoji.engrenagem),
            ),
            new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                .setCustomId(`${userid}_configticket`)
                .setLabel("Voltar")
                .setStyle(2)
                .setEmoji(emoji.voltar)
            )
        ]
    })
}

async function configembedfora(interaction, client) {
    const customId = interaction.customId;
    const userid = customId.split("_")[0];
    const fora = await ticket.embed.get("fora");
    const embed = new EmbedBuilder().setTitle(fora.title).setColor(fora.cor).setDescription(fora.description);

    if(fora.footer !== "remover") {
        embed.setFooter({text: `${fora.footer}`});
    }
    if(fora.banner.startsWith("https://")) {
        embed.setImage(fora.banner);
    }


    await interaction.update({
        embeds:[
            embed.setAuthor({name:`${interaction.guild.name} | Configurar Embed Fora`})
        ],
        components:[
            new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                .setCustomId("iasndyusandyiasunasyu")
                .setLabel(`${fora.button.label}`)
                .setDisabled(true)
                .setStyle(fora.button.cor)
                .setEmoji(fora.button.emoji)
            ),
            new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                .setCustomId(`${userid}_tituloembedfora`)
                .setLabel("Alterar Titulo")
                .setEmoji(emoji.engrenagem)
                .setStyle(1),
                new ButtonBuilder()
                .setCustomId(`${userid}_descembedfora`)
                .setLabel("Alterar Descrição")
                .setEmoji(emoji.engrenagem)
                .setStyle(1),
                new ButtonBuilder()
                .setCustomId(`${userid}_footerembedfora`)
                .setLabel("Alterar Rodapé")
                .setEmoji(emoji.engrenagem)
                .setStyle(1),
            ),
            new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                .setCustomId(`${userid}_bannerembedfora`)
                .setLabel("Alterar Banner")
                .setEmoji(emoji.imagem)
                .setStyle(1),
                new ButtonBuilder()
                .setCustomId(`${userid}_corembed`)
                .setLabel("Alterar Cor da Embed")
                .setEmoji(emoji.pasta)
                .setStyle(1),
                new ButtonBuilder()
                .setCustomId(`${userid}_buttonembedfora`)
                .setLabel("Modificar Botões da Embed")
                .setEmoji(emoji.mouse)
                .setStyle(1),
                new ButtonBuilder()
                .setCustomId(`${userid}_resetembedfora`)
                .setLabel("Resetar Embed")
                .setEmoji(emoji.loading)
                .setStyle(4),
            ),
            new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                .setCustomId(`${userid}_configembed`)
                .setLabel("Voltar")
                .setEmoji(emoji.voltar)
                .setStyle(2),
            )
        ]
    })    
}

async function configembedforaedit(interaction, client) {
    const customId = interaction.customId;
    const userid = customId.split("_")[0];
    const fora = await ticket.embed.get("fora");
    const embed = new EmbedBuilder().setTitle(fora.title).setColor(fora.cor).setDescription(fora.description);

    if(fora.footer !== "remover") {
        embed.setFooter({text: `${fora.footer}`});
    }
    if(fora.banner.startsWith("https://")) {
        embed.setImage(fora.banner);
    }


    await interaction.message.edit({
        embeds:[
            embed.setAuthor({name:`${interaction.guild.name} | Configurar Embed Fora`})
        ],
        components:[
            new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                .setCustomId("iasndyusandyiasunasyu")
                .setLabel(`${fora.button.label}`)
                .setDisabled(true)
                .setStyle(fora.button.cor)
                .setEmoji(fora.button.emoji)
            ),
            new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                .setCustomId(`${userid}_tituloembedfora`)
                .setLabel("Alterar Titulo")
                .setEmoji(emoji.engrenagem)
                .setStyle(1),
                new ButtonBuilder()
                .setCustomId(`${userid}_descembedfora`)
                .setLabel("Alterar Descrição")
                .setEmoji(emoji.engrenagem)
                .setStyle(1),
                new ButtonBuilder()
                .setCustomId(`${userid}_footerembedfora`)
                .setLabel("Alterar Rodapé")
                .setEmoji(emoji.engrenagem)
                .setStyle(1),
            ),
            new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                .setCustomId(`${userid}_bannerembedfora`)
                .setLabel("Alterar Banner")
                .setEmoji(emoji.imagem)
                .setStyle(1),
                new ButtonBuilder()
                .setCustomId(`${userid}_corembed`)
                .setLabel("Alterar Cor da Embed")
                .setEmoji(emoji.pasta)
                .setStyle(1),
                new ButtonBuilder()
                .setCustomId(`${userid}_buttonembedfora`)
                .setLabel("Modificar Botões da Embed")
                .setEmoji(emoji.mouse)
                .setStyle(1),
                new ButtonBuilder()
                .setCustomId(`${userid}_resetembedfora`)
                .setLabel("Resetar Embed")
                .setEmoji(emoji.loading)
                .setStyle(4),
            ),
            new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                .setCustomId(`${userid}_configembed`)
                .setLabel("Voltar")
                .setEmoji(emoji.voltar)
                .setStyle(2),
            )
        ]
    })
    
}

async function buttonembedfora(interaction, client) {
    const customId = interaction.customId;
    const userid = customId.split("_")[0];
    const infobutton = await ticket.embed.get("fora.button");
    const cor = convertercorbutton(infobutton.cor);
    await interaction.update({
        embeds:[
            new EmbedBuilder()
            .setThumbnail(interaction.client.user.displayAvatarURL())
            .setFooter({text:`${interaction.client.user.username} - Todos os Direitos Reservados`, iconURL: interaction.client.user.displayAvatarURL()})
            .setTitle(`${interaction.guild.name} | Configurar Botão Embed`)
            .setDescription(`Texto do Botão: ${infobutton.label} \n\n Cor do Botão: ${cor} \n\n Emoji do Botão: ${infobutton.emoji}`)
        ],
        components:[
            new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                .setCustomId(`${userid}_alterartextbutton`)
                .setLabel("Alterar Texto Botão")
                .setStyle(1)
                .setEmoji(emoji.engrenagem),
                new ButtonBuilder()
                .setCustomId(`${userid}_alterarcolorbutton`)
                .setLabel("Alterar Cor Botão")
                .setStyle(1)
                .setEmoji(emoji.engrenagem),
                new ButtonBuilder()
                .setCustomId(`${userid}_alteraremojibutton`)
                .setLabel("Alterar Emoji Botão")
                .setStyle(1)
                .setEmoji(emoji.engrenagem),
            ),
            new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                .setCustomId(`${userid}_embedfora`)
                .setLabel("Voltar")
                .setStyle(2)
                .setEmoji(emoji.voltar),
            )
        ]
    })
}

async function buttonembedforaedit(interaction, client) {
    const customId = interaction.customId;
    const userid = customId.split("_")[0];
    const infobutton = await ticket.embed.get("fora.button");
    const cor = convertercorbutton(infobutton.cor);
    await interaction.message.edit({
        embeds:[
            new EmbedBuilder()
            .setThumbnail(interaction.client.user.displayAvatarURL())
            .setFooter({text:`${interaction.client.user.username} - Todos os Direitos Reservados`, iconURL: interaction.client.user.displayAvatarURL()})
            .setTitle(`${interaction.guild.name} | Configurar Botão Embed`)
            .setDescription(`Texto do Botão: ${infobutton.label} \n\n Cor do Botão: ${cor} \n\n Emoji do Botão: ${infobutton.emoji}`)
        ],
        components:[
            new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                .setCustomId(`${userid}_alterartextbutton`)
                .setLabel("Alterar Texto Botão")
                .setStyle(1)
                .setEmoji(emoji.engrenagem),
                new ButtonBuilder()
                .setCustomId(`${userid}_alterarcolorbutton`)
                .setLabel("Alterar Cor Botão")
                .setStyle(1)
                .setEmoji(emoji.engrenagem),
                new ButtonBuilder()
                .setCustomId(`${userid}_alteraremojibutton`)
                .setLabel("Alterar Emoji Botão")
                .setStyle(1)
                .setEmoji(emoji.engrenagem),
            ),
            new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                .setCustomId(`${userid}_embedfora`)
                .setLabel("Voltar")
                .setStyle(2)
                .setEmoji(emoji.voltar),
            )
        ]
    })
}

function convertercorbutton(color) {
    let cor = "Cinza"
    switch (color) {
        case 1: cor = "`Azul - Primario`"
            
            break;
            case 2: cor = "`Cinza - Segundario`"
                
                break;
                case 3: cor = "`Verde - Sucesso`"
                    
                    break;
                    case 4: cor = "`Vermelho - Perigo`"
                        
                        break;
    
        default: cor = "`Cinza - Segundario`"
            break;
    }

    return cor;
}

async function configembeddentro(interaction, client) {
    const customId = interaction.customId;
    const userid = customId.split("_")[0];
    const all = await ticket.embed.get("dentro");
    const embed = new EmbedBuilder().setTitle(all.title).setDescription(all.description).setColor(all.cor)
    if(all.footer !== "remover") {
        embed.setFooter({text: `${all.footer}`});
    }
    if(all.banner.startsWith("https://")) {
        embed.setImage(all.banner);
    }
    await interaction.update({
        embeds:[
            embed.setAuthor({name:`${interaction.guild.name} | Configurar Embed Dentro`})
        ],
        components:[
            new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                .setCustomId(`${userid}_titleembeddentro`)
                .setLabel("Alterar Titulo")
                .setStyle(1)
                .setEmoji(emoji.engrenagem),
                new ButtonBuilder()
                .setCustomId(`${userid}_descembeddentro`)
                .setLabel("Alterar Descrição")
                .setStyle(1)
                .setEmoji(emoji.engrenagem),
                new ButtonBuilder()
                .setCustomId(`${userid}_footerembeddentro`)
                .setLabel("Alterar Footer")
                .setStyle(1)
                .setEmoji(emoji.engrenagem),
                new ButtonBuilder()
                .setCustomId(`${userid}_bannerembeddentro`)
                .setLabel("Alterar Banner")
                .setStyle(1)
                .setEmoji(emoji.engrenagem),
                new ButtonBuilder()
                .setCustomId(`${userid}_corembeddentro123`)
                .setLabel("Alterar Cor")
                .setStyle(1)
                .setEmoji(emoji.engrenagem),
            ),
            new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                .setCustomId(`${userid}_resetembeddentro`)
                .setLabel("Resetar Embed")
                .setStyle(4)
                .setEmoji(emoji.loading),
                new ButtonBuilder()
                .setCustomId(`${userid}_configembed`)
                .setLabel("Voltar")
                .setEmoji(emoji.voltar)
                .setStyle(2),
            )
        ]
    })
    
}

async function configembeddentroedit(interaction, client) {
    const customId = interaction.customId;
    const userid = customId.split("_")[0];
    const all = await ticket.embed.get("dentro");
    const embed = new EmbedBuilder().setTitle(all.title).setDescription(all.description).setColor(all.cor)
    if(all.footer !== "remover") {
        embed.setFooter({text: `${all.footer}`});
    }
    if(all.banner.startsWith("https://")) {
        embed.setImage(all.banner);
    }
    await interaction.message.edit({
        embeds:[
            embed.setAuthor({name:`${interaction.guild.name} | Configurar Embed Dentro`})
        ],
        components:[
            new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                .setCustomId(`${userid}_titleembeddentro`)
                .setLabel("Alterar Titulo")
                .setStyle(1)
                .setEmoji(emoji.engrenagem),
                new ButtonBuilder()
                .setCustomId(`${userid}_descembeddentro`)
                .setLabel("Alterar Descrição")
                .setStyle(1)
                .setEmoji(emoji.engrenagem),
                new ButtonBuilder()
                .setCustomId(`${userid}_footerembeddentro`)
                .setLabel("Alterar Footer")
                .setStyle(1)
                .setEmoji(emoji.engrenagem),
                new ButtonBuilder()
                .setCustomId(`${userid}_bannerembeddentro`)
                .setLabel("Alterar Banner")
                .setStyle(1)
                .setEmoji(emoji.engrenagem),
                new ButtonBuilder()
                .setCustomId(`${userid}_corembeddentro123`)
                .setLabel("Alterar Cor")
                .setStyle(1)
                .setEmoji(emoji.engrenagem),
            ),
            new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                .setCustomId(`${userid}_resetembeddentro`)
                .setLabel("Resetar Embed")
                .setStyle(4)
                .setEmoji(emoji.loading),
                new ButtonBuilder()
                .setCustomId(`${userid}_configembed`)
                .setLabel("Voltar")
                .setEmoji(emoji.voltar)
                .setStyle(2),
            )
        ]
    })
    
}


module.exports = {
    configvendas,
    configvendasedit,
    botconfig,
    configpayments,
    configmercadopago,
    configmercadopagoedit,
    configchannels,
    configticket,
    configgeraisticket,
    configembed,
    configembedfora,
    configembedforaedit,
    buttonembedfora,
    buttonembedforaedit,
    configembeddentro,
    configembeddentroedit,
}